package hell.entities.heroes;

public class Barbarian extends Heroes {
    public Barbarian(String name) {
        super(name, 90, 25, 10, 350, 150);
    }
}
