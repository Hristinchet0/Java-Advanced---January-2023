package hell.entities.heroes;

public class Assassin extends Heroes {
    public Assassin(String name) {
        super(name, 25, 100, 15, 150, 300);
    }
}
